package com.assignment.pages;

import org.openqa.selenium.By;

public class Appliance 
{
	public static By viewcart = By.xpath("//div[@class=\"xtXmba\"]");
	public static By home_btn = By.xpath("//div[@class=\"_3qX0zy\"]");

}

