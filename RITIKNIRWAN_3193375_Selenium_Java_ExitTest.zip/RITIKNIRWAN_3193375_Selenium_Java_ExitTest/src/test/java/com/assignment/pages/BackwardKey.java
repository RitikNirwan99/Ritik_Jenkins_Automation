package com.assignment.pages;

import org.openqa.selenium.By;

public class BackwardKey
{
	public static By viewcart = By.xpath("//div[@class=\"_24OVr-\"]");
	
}