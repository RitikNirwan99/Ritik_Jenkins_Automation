package com.assignment.pages;

import org.openqa.selenium.By;

public class LogInPage {
	
	public static By btn_login = By.xpath( "//a[text()=\"Login\"]");
    public static By input_user = By.xpath( "//input[@class=\"_2IX_2- VJZDxU\"]");
    public static By input_password = By.xpath("//input[@class=\"_2IX_2- _3mctLh VJZDxU\"]");
    public static By btn_submit = By.xpath("//button[@class=\"_2KpZ6l _2HKlqd _3AWRsL\"]");

}

