package com.assignment.pages;

public class MoreNotificationPreferences {

}
