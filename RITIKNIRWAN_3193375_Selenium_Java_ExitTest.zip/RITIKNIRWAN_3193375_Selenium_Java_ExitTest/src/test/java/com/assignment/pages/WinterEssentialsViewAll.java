package com.assignment.pages;

import org.openqa.selenium.By;

public class WinterEssentialsViewAll
{
	public static By viewcart = By.xpath("//a[@class=\"_2KpZ6l _3dESVI\"]");
	
}