package com.assignment.pages;

import org.openqa.selenium.By;

public class GroceryPincode {
	
	public static By input_grocery = By.xpath("//input[@class=\"_166SQN\"]");
	
}