package com.assignment.pages;

import org.openqa.selenium.By;

public class SearchBar {
    
	public static By input_user = By.xpath( "//input[@class=\"_3704LK\"]");
    
    
}
