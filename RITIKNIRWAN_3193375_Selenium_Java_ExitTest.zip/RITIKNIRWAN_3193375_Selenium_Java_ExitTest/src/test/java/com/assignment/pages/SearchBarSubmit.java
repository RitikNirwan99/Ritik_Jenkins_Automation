package com.assignment.pages;

import org.openqa.selenium.By;

public class SearchBarSubmit 
{
	public static By btn_clk = By.xpath("//div[@class=\"_3qX0zy\"]");

}
