package com.assignment.pages;

import org.openqa.selenium.By;

public class Grocery {
	public static By btn_grocery = By.xpath("//div[@class=\"xtXmba\"]");

}