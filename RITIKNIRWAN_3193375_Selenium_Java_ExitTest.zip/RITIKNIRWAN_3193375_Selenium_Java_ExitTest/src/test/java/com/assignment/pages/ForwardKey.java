package com.assignment.pages;

import org.openqa.selenium.By;

public class ForwardKey
{
	public static By viewcart = By.xpath("//div[@class=\\\"_2t2dSp\\\"]");
	
}