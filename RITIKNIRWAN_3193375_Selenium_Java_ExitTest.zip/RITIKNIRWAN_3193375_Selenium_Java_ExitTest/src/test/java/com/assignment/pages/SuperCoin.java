package com.assignment.pages;

import org.openqa.selenium.By;

public class SuperCoin {
	public static By btn_login = By.xpath("//div[@class=\"exehdJ\"]");
    public static By input_user = By.xpath("//div[@class=\\\"_3vhnxf\\\" and text()=\\\"SuperCoin Zone\\\"]");


}
