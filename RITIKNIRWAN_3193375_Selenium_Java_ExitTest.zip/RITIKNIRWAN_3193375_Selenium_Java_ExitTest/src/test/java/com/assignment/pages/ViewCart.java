package com.assignment.pages;

import org.openqa.selenium.By;

public class ViewCart 
{
	public static By viewcart = By.xpath("//div[@class=\"KK-o3G\"]");
	
}