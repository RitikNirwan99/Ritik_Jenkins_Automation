package com.assignment.pages;

import org.openqa.selenium.By;

public class InputInSearchBar {
	public static By btn_submit = By.className( "L0Z3Pu");

}
