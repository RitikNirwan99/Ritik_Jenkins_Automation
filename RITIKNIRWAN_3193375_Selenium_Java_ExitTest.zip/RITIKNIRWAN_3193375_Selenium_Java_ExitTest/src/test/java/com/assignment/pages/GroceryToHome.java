package com.assignment.pages;

import org.openqa.selenium.By;

public class GroceryToHome
{
	
	public static By btn_home = By.xpath("//img[@class=\"_1fqNI-\"]");
}