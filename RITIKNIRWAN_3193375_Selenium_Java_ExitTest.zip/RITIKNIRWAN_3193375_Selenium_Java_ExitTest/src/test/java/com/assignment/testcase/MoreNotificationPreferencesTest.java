package com.assignment.testcase;

public class MoreNotificationPreferencesTest {

}
