package com.assignment.utilities;

public class ScreenShot {

}
